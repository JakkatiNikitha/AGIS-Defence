AGIS Defence System
===================

Installation Instructions:
1. Make sure you have Python 3.8 or later installed
2. Run install.bat to set up the environment
3. After installation, use the desktop shortcut or start.bat to run the system

For support, visit: https://agis-defence.com/support
