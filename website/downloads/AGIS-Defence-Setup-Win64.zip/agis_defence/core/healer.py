"""System healing module for AGIS Defence System."""

from ..healing.healer import SystemHealer
 
# Initialize the system healer
healer = SystemHealer() 