"""Historical data management module for AGIS Defence System."""

from ..models.historical_data import HistoricalData
 
# Initialize the historical data manager
historical_data = HistoricalData() 