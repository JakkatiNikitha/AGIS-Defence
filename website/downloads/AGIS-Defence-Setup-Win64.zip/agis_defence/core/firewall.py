"""Firewall management module for AGIS Defence System."""

from ..firewall.manager import FirewallManager
 
# Initialize the firewall manager
firewall_manager = FirewallManager() 