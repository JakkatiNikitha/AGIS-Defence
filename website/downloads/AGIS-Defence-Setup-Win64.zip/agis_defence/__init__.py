"""
AGIS Defence System - AI-powered security monitoring and threat detection
"""

from agis_defence.app import app

__version__ = '1.0.0'
__author__ = 'AGIS Defence Team'

# This file makes the agis_defence directory a Python package 